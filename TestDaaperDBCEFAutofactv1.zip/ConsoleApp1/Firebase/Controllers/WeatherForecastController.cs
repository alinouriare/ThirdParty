﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Firebase.Database;
using Firebase.Database.Query;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Firebase.Controllers
{
    public class LoginData
    {

        public string TimestampUtc { get; set; }

}
[ApiController]
[Route("[controller]")]
public class WeatherForecastController : ControllerBase
{
    private static readonly string[] Summaries = new[]
    {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

    private readonly ILogger<WeatherForecastController> _logger;

    public WeatherForecastController(ILogger<WeatherForecastController> logger)
    {
        _logger = logger;
    }

    //[HttpGet]
    //public IEnumerable<WeatherForecast> Get()
    //{
    //    var rng = new Random();
    //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
    //    {
    //        Date = DateTime.Now.AddDays(index),
    //        TemperatureC = rng.Next(-20, 55),
    //        Summary = Summaries[rng.Next(Summaries.Length)]
    //    })
    //    .ToArray();
    //}

    [Authorize]
    [HttpGet("protected")]
    public string Protected()
    {
        return "This endpoint is protected.";
    }
    [Authorize]
    [HttpGet("wdd")]

    public dynamic WE()
    {
        return new
        {
            name = User.Claims.Where(x => x.Type == "name").FirstOrDefault().Value,
            email = User.Claims.Where(x => x.Type == "email").FirstOrDefault().Value,
            // picture = User.Claims.Where(x => x.Type == "picture").FirstOrDefault().Value,
        };
    }
        [HttpGet("About")]
        public async Task<ActionResult> About()
    {
        //Simulate test user data and login timestamp
        var userId = "8XO95M5G34R2JtxaU9WWurVdM7H3";
        var currentLoginTime = DateTime.UtcNow.ToString("MM/dd/yyyy HH:mm:ss");

        //Save non identifying data to Firebase
        var currentUserLogin = new LoginData() { TimestampUtc = currentLoginTime };
        var firebaseClient = new FirebaseClient("https://myproject-bd926.firebaseio.com/");
        var result = await firebaseClient
          .Child("Users/" + userId + "/Logins")
          .PostAsync(currentUserLogin);

        //Retrieve data from Firebase
        var dbLogins = await firebaseClient
          .Child("Users")
          .Child(userId)
          .Child("Logins")
          .OnceAsync<LoginData>();

        var timestampList = new List<DateTime>();

        //Convert JSON data to original datatype
        foreach (var login in dbLogins)
        {
            timestampList.Add(Convert.ToDateTime(login.Object.TimestampUtc).ToLocalTime());
        }

        //Pass data to the view
        //ViewBag.CurrentUser = userId;
        //ViewBag.Logins = timestampList.OrderByDescending(x => x);
        return Ok();
    }
}
}
