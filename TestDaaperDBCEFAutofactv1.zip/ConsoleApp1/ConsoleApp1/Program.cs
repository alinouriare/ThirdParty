﻿using Autofac;
using Autofac.Extensions.DependencyInjection;
using Autofac.Extras.DynamicProxy;
using Castle.Core.Configuration;
using ConsoleApp1.model;
using ConsoleApp1.ModelCache;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

using StackExchange.Redis;
using FirebaseAdmin;
using Google.Apis.Auth.OAuth2;
using System.IO;
using FirebaseAdmin.Messaging;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {

        private static IContainer Container { get; set; }
        public static Microsoft.Extensions.Configuration.IConfiguration configuration { get; set; }
         static async Task Main(string[] args)
        {
           
        }
        private async Task Run()
        {
           
        }
        private static async Task FireeBase()
        {
            var defaultApp = FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Auth.json")),
            });
            Console.WriteLine(defaultApp.Name); // "[DEFAULT]"
            var message = new Message()
            {
                Data = new Dictionary<string, string>()
                {
                    ["FirstName"] = "John",
                    ["LastName"] = "Doe"
                },
                Notification = new Notification
                {
                    Title = "Message Title",
                    Body = "Message Body"
                },

                //Token = "d3aLewjvTNw:APA91bE94LuGCqCSInwVaPuL1RoqWokeSLtwauyK-r0EmkPNeZmGavSG6ZgYQ4GRjp0NgOI1p-OAKORiNPHZe2IQWz5v1c3mwRE5s5WTv6_Pbhh58rY0yGEMQdDNEtPPZ_kJmqN5CaIc",
                Topic = "news"
            };
            var messaging = FirebaseMessaging.DefaultInstance;
            var result = await messaging.SendAsync(message);
            Console.WriteLine(result); //projects/myapp/messages/2492588335721724324
        }

        private static void Chachinspector()
        {
            var provider = new Microsoft.Extensions.DependencyInjection.ServiceCollection();


            Stopwatch sw = new Stopwatch();
            sw.Start();
            var redis = ConnectionMultiplexer.Connect("127.0.0.1");
            provider.AddScoped<IDatabase>(c => redis.GetDatabase());


            var bulider = new ContainerBuilder();
            bulider.Register(i => new Logger(Console.Out));

            bulider.RegisterType<RedisCaching>();
            bulider.RegisterType<TestDBConnection>().As<ITest>().WithParameter("co", "Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;")
                .EnableInterfaceInterceptors().InterceptedBy(typeof(Logger)).InterceptedBy(typeof(RedisCaching)); ;
            bulider.Populate(provider);
            Container = bulider.Build();
            using (var scope = Container.BeginLifetimeScope())
            {
                var wr = scope.Resolve<ITest>();

                wr.Add(11);
            }
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void Inspectror()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var bulider = new ContainerBuilder();
            bulider.Register(i => new Logger(Console.Out));
            bulider.RegisterType<TestDBConnection>().As<ITest>().WithParameter("co", "Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;")
                .EnableInterfaceInterceptors().InterceptedBy(typeof(Logger)); ;
            Container = bulider.Build();

            using (var scope = Container.BeginLifetimeScope())
            {
                var wr = scope.Resolve<ITest>();
                wr.Add(9);
            }
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void DapperDi()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var bulider = new ContainerBuilder();
            bulider.RegisterType<TestDapper>().As<ITest>().WithParameter("co", "Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;");
            Container = bulider.Build();

            using (var scope = Container.BeginLifetimeScope())
            {
                var wr = scope.Resolve<ITest>();
                wr.Add(10);
            }
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void dbconnctionDI()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var bulider = new ContainerBuilder();
            bulider.RegisterType<TestDBConnection>().As<ITest>().WithParameter("co", "Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;");
            Container = bulider.Build();

            using (var scope = Container.BeginLifetimeScope())
            {
                var wr = scope.Resolve<ITest>();
                wr.Add(9);
            }
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void Daaper()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            ITest mo = new TestDapper("Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;");
            mo.Add(8);
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void Autofactef()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            var builder = new ContainerBuilder();
            builder.RegisterType<wcf>();
            builder.RegisterType<TestEF>().As<ITest>();
            Container = builder.Build();


            using (var scope = Container.BeginLifetimeScope())
            {
                var writer = scope.Resolve<ITest>();
                writer.Add(7);
            }
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void efNew()
        {
            wcf a = new wcf();
            Stopwatch sw = new Stopwatch();
            sw.Start();

            ITest a1 = new TestEF(a);
            a1.Add(6);
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void dBCONNECTION()
        {
            Stopwatch sw = new Stopwatch();
            sw.Start();

            ITest a1 = new TestDBConnection("Server =.; Initial Catalog = WCF; Integrated Security = True; Connection Timeout = 30;");
            a1.Add(4);
            sw.Stop();

            Console.WriteLine($"AAAAAAAAAAAAAAAAAAAAAAAA{sw.ElapsedMilliseconds}");
        }

        private static void leftjoin()
        {
            IList<Student> studentList = new List<Student>() {
    new Student() { StudentID = 1, StudentName = "John", StandardID =1 ,Age=18},
    new Student() { StudentID = 2, StudentName = "Moin", StandardID =1 ,Age=21},
    new Student() { StudentID = 3, StudentName = "Bill", StandardID =2 ,Age=18},
    new Student() { StudentID = 4, StudentName = "Ram" , StandardID =2,Age=20 },
    new Student() { StudentID = 5, StudentName = "Ron" ,Age=21 }
};

            IList<Standard> techer = new List<Standard>() {
    new Standard(){ StandardID = 1, StandardName="Standard 1"},
    new Standard(){ StandardID = 2, StandardName="Standard 2"},
    new Standard(){ StandardID = 3, StandardName="Standard 3"}
};

            // Grouby(studentList);
            var qq = (from w in techer
                      join e in studentList
                      on w.StandardID equals e.StandardID
                      select new
                      {
                          name = w.StandardName,
                          names = e.StudentName
                      }).ToList();





            var rrr = (from t in techer
                       join s in studentList
                       on t.StandardID equals s.StandardID into snull
                       from s in snull.DefaultIfEmpty()

                       select new
                       {

                           name = t.StandardName,
                           namess = s == null ? "null" : s.StudentName
                       }
                     ).ToList();


            var www = (from s in studentList
                       join t in techer
                       on s.StandardID equals t.StandardID into snull
                       from t in snull.DefaultIfEmpty()

                       select new
                       {

                           name = s.StudentName,
                           namess = t == null ? "null" : t.StandardName
                       }
                   ).ToList();
        }

        private static void grupjoin(IList<Student> studentList, IList<Standard> techer)
        {
            var join = studentList.Join(techer, s => s.StandardID, t => t.StandardID, (s, t) => new
            {

                st = s.StudentName,
                te = t.StandardName
            });


            var joinG = techer.GroupJoin(studentList, t => t.StandardID, s => s.StandardID, (t, sG) => new { stu = sG, name = t.StandardName });


            foreach (var item in joinG)
            {
                var aa = item.stu.Sum(s => s.Age);
                Console.WriteLine(aa + "dddddddddddd" + item.name);
            }
        }

        private static void Grouby(IList<Student> studentList)
        {
            var groupedResult = studentList.GroupBy(s => s.Age).Select(a => new
            {

                total = a.Sum(c => c.StudentID),
                a = a.Key
            });


            foreach (var item in groupedResult)
            {
                Console.WriteLine(item.a);
                Console.WriteLine(item.total);
            }
        }
    }
}
