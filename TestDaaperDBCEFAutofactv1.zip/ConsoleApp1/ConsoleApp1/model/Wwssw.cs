﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1.model
{
    public partial class Wwssw
    {
        public int Oe { get; set; }
        public int? Custid { get; set; }
        public string Shipaddress { get; set; }
    }
}
