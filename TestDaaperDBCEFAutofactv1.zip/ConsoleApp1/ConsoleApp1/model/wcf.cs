﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ConsoleApp1.model
{
    public partial class wcf : DbContext
    {
        public wcf()
        {
        }

        public wcf(DbContextOptions<wcf> options)
            : base(options)
        {
        }

        public virtual DbSet<OrderDetails> OrderDetails { get; set; }
        public virtual DbSet<OrderValues> OrderValues { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<Persons> Persons { get; set; }
        public virtual DbSet<Transactions> Transactions { get; set; }
        public virtual DbSet<UsersApps> UsersApps { get; set; }
        public virtual DbSet<Wwssw> Wwssw { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=.;Database=WCF;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<OrderDetails>(entity =>
            {
                entity.HasKey(e => new { e.Orderid, e.Productid });

                entity.ToTable("OrderDetails", "Sales");

                entity.Property(e => e.Orderid).HasColumnName("orderid");

                entity.Property(e => e.Productid).HasColumnName("productid");

                entity.Property(e => e.Discount)
                    .HasColumnName("discount")
                    .HasColumnType("numeric(4, 3)");

                entity.Property(e => e.Qty)
                    .HasColumnName("qty")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Unitprice)
                    .HasColumnName("unitprice")
                    .HasColumnType("money");

                entity.HasOne(d => d.Order)
                    .WithMany(p => p.OrderDetails)
                    .HasForeignKey(d => d.Orderid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_OrderDetails_Orders");
            });

            modelBuilder.Entity<OrderValues>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("OrderValues", "Sales");

                entity.Property(e => e.Custid).HasColumnName("custid");

                entity.Property(e => e.Empid).HasColumnName("empid");

                entity.Property(e => e.Orderdate)
                    .HasColumnName("orderdate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Orderid).HasColumnName("orderid");

                entity.Property(e => e.Qty).HasColumnName("qty");

                entity.Property(e => e.Requireddate)
                    .HasColumnName("requireddate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Shippeddate)
                    .HasColumnName("shippeddate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Shipperid).HasColumnName("shipperid");

                entity.Property(e => e.Val)
                    .HasColumnName("val")
                    .HasColumnType("numeric(12, 2)");
            });

            modelBuilder.Entity<Orders>(entity =>
            {
                entity.HasKey(e => e.Orderid);

                entity.ToTable("Orders", "Sales");

                entity.Property(e => e.Orderid).HasColumnName("orderid");

                entity.Property(e => e.Custid).HasColumnName("custid");

                entity.Property(e => e.Empid).HasColumnName("empid");

                entity.Property(e => e.Freight)
                    .HasColumnName("freight")
                    .HasColumnType("money");

                entity.Property(e => e.Orderdate)
                    .HasColumnName("orderdate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Requireddate)
                    .HasColumnName("requireddate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Shipaddress)
                    .IsRequired()
                    .HasColumnName("shipaddress")
                    .HasMaxLength(60);

                entity.Property(e => e.Shipcity)
                    .IsRequired()
                    .HasColumnName("shipcity")
                    .HasMaxLength(15);

                entity.Property(e => e.Shipcountry)
                    .IsRequired()
                    .HasColumnName("shipcountry")
                    .HasMaxLength(15);

                entity.Property(e => e.Shipname)
                    .IsRequired()
                    .HasColumnName("shipname")
                    .HasMaxLength(40);

                entity.Property(e => e.Shippeddate)
                    .HasColumnName("shippeddate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Shipperid).HasColumnName("shipperid");

                entity.Property(e => e.Shippostalcode)
                    .HasColumnName("shippostalcode")
                    .HasMaxLength(10);

                entity.Property(e => e.Shipregion)
                    .HasColumnName("shipregion")
                    .HasMaxLength(15);
            });

            modelBuilder.Entity<Persons>(entity =>
            {
                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.Family).HasMaxLength(50);

                entity.Property(e => e.Mobile).HasMaxLength(50);

                entity.Property(e => e.Name).HasMaxLength(50);
            });

            modelBuilder.Entity<Transactions>(entity =>
            {
                entity.HasKey(e => new { e.Actid, e.Tranid });

                entity.Property(e => e.Actid).HasColumnName("actid");

                entity.Property(e => e.Tranid).HasColumnName("tranid");

                entity.Property(e => e.Val)
                    .HasColumnName("val")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<UsersApps>(entity =>
            {
                entity.HasKey(e => e.Code)
                    .HasName("PK__Users_Ap__A25C5AA628EC70A7");

                entity.ToTable("Users_Apps");

                entity.Property(e => e.Code).ValueGeneratedNever();

                entity.Property(e => e.App)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.EndTime)
                    .HasColumnName("End_Time")
                    .HasColumnType("datetime");

                entity.Property(e => e.StartTime)
                    .HasColumnName("Start_Time")
                    .HasColumnType("datetime");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Wwssw>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("wwssw");

                entity.Property(e => e.Custid).HasColumnName("custid");

                entity.Property(e => e.Oe).HasColumnName("oe");

                entity.Property(e => e.Shipaddress)
                    .IsRequired()
                    .HasColumnName("shipaddress")
                    .HasMaxLength(60);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
