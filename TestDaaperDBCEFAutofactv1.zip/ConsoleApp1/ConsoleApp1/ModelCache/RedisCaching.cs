﻿using Castle.DynamicProxy;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1.ModelCache
{
    public class RedisCaching : IInterceptor
    {
        private readonly IDatabase _database;

        public RedisCaching(IDatabase database)
        {
            _database = database;
        }
        public void Intercept(IInvocation invocation)
        {
            var name = $"{invocation.Method.DeclaringType}_{invocation.Method.Name}";
            var args = string.Join(", ", invocation.Arguments.Select(a => (a ?? "").ToString()));
            var cacheKey = $"aa";var returnValue=   _database.StringGet(cacheKey );
            if (!returnValue.HasValue)
            {
                invocation.Proceed();
                string re= invocation.ReturnValue.ToString();
                _database.StringSet(cacheKey, "aliiiiiiiiiiiiii");
            }
            else
            {
                invocation.ReturnValue = returnValue;
            }
        }
    }
}
