﻿namespace ConsoleApp1
{
    public class Standard
    {
        public int StandardID { get; set; }


        public string StandardName { get; set; }
    }
}
