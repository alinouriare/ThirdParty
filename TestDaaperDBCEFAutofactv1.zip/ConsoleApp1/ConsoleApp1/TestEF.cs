﻿using ConsoleApp1.model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class TestEF : ITest
    {

        private readonly wcf _db;

        public TestEF(wcf db)
        {
            _db = db;
        }
        public int Add(int a)
        {
            
                int affectedRows = _db.Database.ExecuteSqlCommand($"dbo.tos {a}");

                return affectedRows;
            
           
        }
    }
}
