﻿namespace MVCCore.Session07.Common
{
    public class Teacher :Person
    {
        public string Code { get; set; }
    }

}
