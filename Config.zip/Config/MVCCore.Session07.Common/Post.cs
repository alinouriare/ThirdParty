﻿namespace MVCCore.Session07.Common
{
    public class Post
    {
        public int Id { get; set; }
        public string Body { get; set; }
        public string BlogName{ get; set; }
    }

}
