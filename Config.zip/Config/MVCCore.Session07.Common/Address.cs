﻿namespace MVCCore.Session07.Common
{
    public class Address
    {
        public string AddressLine { get; set; }
        public string PhoneNumber { get; set; }

    }

}
