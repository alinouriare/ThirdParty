﻿using System;

namespace MVCCore.Session07.Common
{
    public static class DbFunctions
    {
        //[DbFunction]
        public static int MyFunction()
        {
            throw new NotImplementedException();
        }
    }

}
