﻿namespace MVCCore.Session07.Common
{
    public class BankAccount
    {
        public int Id { get; set; }
        public string AccNumber { get; set; }
        public Person Person { get; set; }
    }

}
