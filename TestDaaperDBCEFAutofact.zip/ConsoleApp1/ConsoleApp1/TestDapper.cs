﻿using Dapper;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ConsoleApp1
{
    public class TestDapper:ITest
    {
        private readonly IDbConnection _db;

        public TestDapper(string co)
        {
            _db = new SqlConnection(co);
        }

        public int Add(int a)
        {
            int result = _db.Execute("tos", commandType: CommandType.StoredProcedure, param: new
            {
                a = a

            });
            return result;
        }
    }
}
