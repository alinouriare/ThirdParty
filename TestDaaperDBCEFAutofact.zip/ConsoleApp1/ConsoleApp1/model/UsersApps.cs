﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1.model
{
    public partial class UsersApps
    {
        public int Code { get; set; }
        public string App { get; set; }
        public string UserId { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
    }
}
