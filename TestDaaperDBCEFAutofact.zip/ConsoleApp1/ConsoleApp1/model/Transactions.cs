﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1.model
{
    public partial class Transactions
    {
        public int Actid { get; set; }
        public int Tranid { get; set; }
        public decimal Val { get; set; }
    }
}
