﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ConsoleApp1
{
 public   class TestDBConnection:ITest
    {
        public int Add(int a)
        {
            SqlCommand cmd = new SqlCommand("tos",_db);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@a", a);
            _db.Open();
            
            int result = cmd.ExecuteNonQuery();
            return result;

        }

        private readonly SqlConnection _db;

        public TestDBConnection(string co)
        {
            _db = new SqlConnection(co);
        }
    }
}
