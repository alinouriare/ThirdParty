﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class Test : ITest
    {
        private readonly SqlConnection _con;

        public Test(string con)
        {
            _con = new SqlConnection(con);
        }
        public int Add(int a)
        {
            int e = 4;
            var aa = asa(e);
                SqlCommand cmd = new SqlCommand("tos", _con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@a", a);
            _con.Open();
            int rowAffected = cmd.ExecuteNonQuery();
            _con.Close();
            return rowAffected;
        }

        public model get(int a)
        {
            throw new NotImplementedException();
        }

        //public void get(int a)
        //{
        //    var t = (model)asa(a);
        //}


        private DataTable asa(int a)
        {
            SqlCommand cmd = new SqlCommand("sp", _con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@a", a);
            
            _con.Open();

            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            da.Fill(dt);
            return dt;
        }
    }
}
