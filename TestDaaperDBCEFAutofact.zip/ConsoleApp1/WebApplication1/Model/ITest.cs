﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Model
{
    public class model
    {

        public int Id { get; set; }

        public string Name { get; set; }

        public string Family { get; set; }


        public string Email { get; set; }

        public string Mobile { get; set; }
    }
         
   public interface ITest
    {

        int Add(int a);

        model get(int a);
    }


    
}
